@echo off
chcp 65001 >nul
title Install Launch Quality shortcut
set "DESKTOP=%USERPROFILE%\Desktop"
set "BAT=%~dp0Run-LaunchQuality.bat"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%DESKTOP%\Launch Quality.lnk'); $s.TargetPath='%~dp0Run-LaunchQuality.bat'; $s.WorkingDirectory='%~dp0'; $s.WindowStyle=7; $s.Description='Launch Quality ERP'; $s.Save(); Write-Host 'Desktop shortcut created'"
echo.
echo Done. Open Launch Quality from the desktop shortcut.
pause
